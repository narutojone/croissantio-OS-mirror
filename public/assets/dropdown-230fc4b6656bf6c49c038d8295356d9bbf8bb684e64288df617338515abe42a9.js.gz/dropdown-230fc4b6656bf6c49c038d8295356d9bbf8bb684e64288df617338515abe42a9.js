$('.js--res-dropdown').on('click', function() {
  $('.res-dropdown').toggle("fast")
})
;
